import React from 'react';
import { ChevronRight } from 'lucide-react';


// @ts-ignore
const IntegrationItem = ({ logo, name, description }) => (
    <div className="flex items-center py-4">
        <img src={logo} alt={name} className="w-10 h-10 rounded-full mr-4" />
        <div className="flex-grow">
            <h3 className="text-base font-semibold text-gray-900">{name}</h3>
            <p className="text-sm text-gray-500">{description}</p>
        </div>
    </div>
);

const QuickAccessCard = () => {
    return (
        <div className="w-80 bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-5">
                <div className="flex justify-center mb-4">
                    <svg className="w-6 h-6 text-gray-800" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 1L1 22h22L12 1z" />
                    </svg>
                </div>
                <h2 className="text-base font-semibold text-center mb-1">快速访问工具</h2>
                <p className="text-xs text-gray-500 text-center mb-4">
                    探索更多工具，提升您的开发体验。
                </p>
                <div className="space-y-2 mb-4">
                    <IntegrationItem
                        logo="/placeholder.svg?height=40&width=40&text=R"
                        name="配置工具"
                        description="快速设置您的开发环境"
                    />
                    <IntegrationItem
                        logo="/placeholder.svg?height=40&width=40&text=E"
                        name="监控面板"
                        description="实时监控应用性能"
                    />
                    <IntegrationItem
                        logo="/placeholder.svg?height=40&width=40&text=S"
                        name="数据库管理"
                        description="高效管理您的数据"
                    />
                </div>
                <div className="border-t border-gray-200 pt-4">
                    <button className="w-full py-2 px-4 bg-white hover:bg-gray-50 text-sm font-medium text-gray-900 rounded border border-gray-300 flex items-center justify-center transition-colors">
                        浏览更多工具
                        <ChevronRight className="w-4 h-4 ml-1" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default QuickAccessCard;