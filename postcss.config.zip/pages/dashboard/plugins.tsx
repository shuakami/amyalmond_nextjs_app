import '@/styles/globals.css'
import PluginHero from '@/plugins/home';
import RobotSideNav from "@/dashboard/sidenav";
import PluginsHeader from "@/plugins/header_hero";
import React from "react";
import PluginsList from "@/plugins/list";
import { PluginSidebar } from "@/plugins/sidebar";

export default function Plugins() {
    const PluginList = [
        {
            id: 1,
            name: "Plugin 1",
            description: "This is a description of plugin 1.",
            version: "1.0.0",
            author: "John Doe",
            lastUpdated: "2023-04-15",
            installed: false,
        },
        {
            id: 2,
            name: "Plugin 2",
            description: "This is a description of plugin 2.",
            version: "2.0.0",
            author: "Jane Roe",
            lastUpdated: "2023-04-16",
            installed: true,
        },
        {
            id: 3,
            name: "Plugin 3",
            description: "This is a description of plugin 3.",
            version: "3.0.0",
            author: "John Smith",
            lastUpdated: "2023-04-17",
            installed: false,
        },
    ];

    return (
        <>
            <div className="flex">
                <RobotSideNav />
                <div className="flex-1 px-12 relative">
                    <PluginsHeader />
                    <div className="absolute left-0 right-0 border-b border-[#EBEBEB]" />
                    <div className="flex mt-8">
                        <div className="w-2/6 flex-shrink-0 mr-8 mt-4">
                            <div className="sticky top-8 max-h-full">
                                <PluginSidebar onPluginClick={() => {}} />
                            </div>
                        </div>
                        <div className="flex-1">
                            <div className="flex flex-col">
                                <PluginHero />
                                <PluginsList />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}