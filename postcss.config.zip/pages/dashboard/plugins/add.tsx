import LoadingPage from "@/components/loading";
import RobotSideNav from "@/dashboard/sidenav";
import ChatList from "@/dashboard/chat/list";
import '@/styles/globals.css'
import PluginsHeader from "@/plugins/header_hero";

import React from "react";
import AddPlugins from "@/plugins/add/home";


const AddPluginsPage = () => {
    return (
        <div className="flex">
            <RobotSideNav/>
            <div className="flex-1 px-12 relative">
                <PluginsHeader/>
                <div className="absolute left-0 right-0 border-b border-[#EBEBEB]"/>
                <div className="flex mt-8">
                    <div className="flex-1">
                        <div className="flex flex-col">
                            <AddPlugins/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddPluginsPage;
