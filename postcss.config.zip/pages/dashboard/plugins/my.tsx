import RobotSideNav from "@/dashboard/sidenav";
import '@/styles/globals.css'
import PluginsHeader from "@/plugins/header_hero";
import React from "react";
import MyPlugins from "@/plugins/my/home";


const MyPluginsPage = () => {
    return (
        <div className="flex">
            <RobotSideNav/>
            <div className="flex-1 px-12 relative">
                <PluginsHeader/>
                <div className="absolute left-0 right-0 border-b border-[#EBEBEB]"/>
                <div className="flex mt-8">
                    <div className="flex-1">
                        <div className="flex flex-col">
                            <MyPlugins/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MyPluginsPage;
